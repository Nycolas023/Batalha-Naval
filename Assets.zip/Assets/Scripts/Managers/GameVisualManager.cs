using System;
using UnityEngine;

public class GameVisualManager : MonoBehaviour {

}
